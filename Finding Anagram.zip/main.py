# Check if two words are anagrams 
# Example:
# find_anagrams("hello", "check") --> False
# find_anagrams("below", "elbow") --> True


def find_anagram(word, anagram):
    if(sorted(word) == sorted(anagram)):
        answer = True
    else:
        answer = False
    return answer
word = input("Enter your first word: ")
anagram = input( "Enter your second word: ")
answer = find_anagram(word, anagram)
print(answer)
print(find_anagram("Hello", "Check"))
print(find_anagram("Below", "Elbow"))


